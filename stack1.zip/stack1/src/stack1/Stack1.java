/*Алгоритм перевода целого числа из десятичной системы счисления в двоичную 
  с использованием стека
*/

package stack1;
import java.util.Scanner;
public class Stack1 {
    public static void main(String[] args) throws ArrayIndexOutOfBoundsException {
       Stack k = new Stack(100);//Стек с ограничением 100 символов
       boolean check; //Переменная для проверки
       int num, x;//num-число в десятичной системе для перевода
       Scanner scanner = new Scanner(System.in);
       System.out.print("Введите число:");
       num=scanner.nextInt();
       check=k.empt();//Проверка стека на наличие данных
       if (check)
       {
       try {//Проверка на выход за пределы массива
           
       while (num>0)
       {
          k.add(num%2);//Добавление в стек поочередно остатков от деления числа на 2
          num /= 2;
       }
       System.out.println("В двоичной системе:");
       check=k.empt();
       while(!check)
       {
           System.out.print(x=k.delete());//Вывод числа на экран, достаем из стека в обратном порядке
           check=k.empt();
       }
       System.out.println("");
       }
       catch(ArrayIndexOutOfBoundsException e)
               {
                 System.out.println("Выход за пределы массива");
               }
       
       
    }
    }
    
}
class Stack {
    private int n;//Размер массива
    private int[] arrayst;//Массив для стека
    private int top;//Вершина стека, счетчик для количества элементов в стеке
    
    public Stack(int n)
    {
        this.n=n;
        arrayst = new int[n];
        top=-1;
    }
    
    public void add(int r)//Метод добавляет число в стек
    {
        arrayst[++top]=r;
    }
    
    public int delete()//Возвращает последний элемент стека с уменьшением счетчика
    {
        return arrayst[top--];
    }
    
    
    public int top()//Возвращает вершину стека
    {
        return arrayst[top];
    }
    
    public boolean empt()//Проверка на наличие в стеке данных
    {
        return (top == -1);
    }
}
