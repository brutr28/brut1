/* Реализация структуры данных очередь при помощи класса ArrayList

*/
package queue;
import java.util.ArrayList;
public class Queue {
    public static void main(String[] args) throws IndexOutOfBoundsException {
        que1 x = new que1(20);//Очередь с начальным размером 20 элементов
        try{
        x.add1(5);//Добавляем поочередно элементы
        x.add1(10);
        x.add1(20);
        x.add1(50);
        x.add1(90);
        x.printque();
        int r;
        r=x.top();
        System.out.println("Первый добавленный элемент " + r);
        r=x.delete();//Удаление элементов
        r=x.delete();
        x.add1(60);//Добавление элемента
        x.printque();
        if (!x.empt())
        {
        r=x.delete();
        printr(r);
        r=x.delete();
        printr(r);
        r=x.delete();
        printr(r);
        x.printque();//Элементы достаются из очереди в том порядке, в котором были добавлены
        }
        x.add1(50);
        x.printque();
        r=x.sizeque();//Размер очереди
        System.out.println("Количество элементов в очереди " + r);
        }
        catch (IndexOutOfBoundsException e)
        {
            System.out.println("Очередь пустая, удаление элементов невозможно");

        }
        
    }
    static void printr(int r)//Функция для печати элементов очереди
    {
        System.out.println("Вытащили элемент из очереди " + r);
    }
    
}
 
class que1
{
    ArrayList<Integer> k;
    
    public que1(int size)//Конструктор для ввода изначального размера arraylist
    {
        k=new ArrayList<Integer>(size);
        System.out.println("Создана очередь");
    }
    public void add1(int n)//Добавление элемента
    {
        k.add(n);
        System.out.println("+" + n);
    }
    
    public int delete()//Удаление элемента, метод возвращает удаленный элемент
    {
        int b=k.get(0);
        k.remove(0);
        return b;
    }
    
    public boolean empt()//Проверка на наличие элементов
    {
        return k.isEmpty();
    }
    
    public int top()//Возвращает первый добавленный элемент
    {       
            return k.get(0);
    }
    
    public void printque()//Выводит всю очередь
    {
        System.out.println(k);
    }
    
    public int sizeque()//Возвращает количество элементов в очереди
    {
        return k.size();
    }
    
    
}