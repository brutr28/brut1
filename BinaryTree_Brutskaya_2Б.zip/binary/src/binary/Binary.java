//���������� ��������� ������
package binary;
import java.util.Objects;

public class Binary {


    public static void main(String[] args) {
       BinaryTreeNode n=new BinaryTreeNode(50,null);
       n.insertNode(49);
       n.insertNode(78);
       System.out.println(n.value);
       System.out.println(n.left.value);
       System.out.println(n.right.value);
       BinaryTreeNode n1=new BinaryTreeNode(45, n.left);
       n1.insertNode(35);
       n1.insertNode(80);
       System.out.println(n1.parent.value);
       System.out.println(n1.left.value);
       System.out.println(n1.right.value);

       
       BinaryTreeNode m=n.findNode(49);
       
        
    }
    
}
class BinaryTreeNode {
    public BinaryTreeNode left;
    public BinaryTreeNode right;
    public BinaryTreeNode parent;
    public Integer value;

    public BinaryTreeNode(Integer value, BinaryTreeNode parent) {
        this.parent = parent;
        this.value = value;
    }
    
    public BinaryTreeNode findNode(Integer value) {
        BinaryTreeNode node = this;
        while (node != null) {
            if (Objects.equals(value, node.value)) {
                System.out.println("���� ������");
                return node;

            }
            if (value < node.value) {
                node = node.left;
            } else {
                node = node.right;
            }
        }

        return null;
    }
    
     public void insertNode(int value) {
        insertNode(value, this);
    }

    private void insertNode(int value, BinaryTreeNode parentNode) {
        if (value < parentNode.value) {
            if (parentNode.left == null) {
                parentNode.left = new BinaryTreeNode(value, parentNode);
            } else {
                insertNode(value, parentNode.left);
            }
        }
        if (value > parentNode.value){
            if (parentNode.right == null){
                parentNode.right = new BinaryTreeNode(value, parentNode);
            } else {
                insertNode(value, parentNode.right);
            }
        }
    }
    
    public void removeNode(int value) {
        removeNode(value, this);
    }

    private BinaryTreeNode removeNode(int value, BinaryTreeNode node) {
        if (node == null) {
            return null;
        }

        if (value < node.value) {
            node.left = removeNode(value, node.left);
        } else if (value > node.value) {
            node.right = removeNode(value, node.right);
        } else {
            if (node.left == null) {
                return node.right;
            }
            if (node.right == null) {
                return node.left;
            }
        }

        BinaryTreeNode original = node;
        node = node.right;
        while (node.left != null) {
            node = node.left;
        }

        node.right = removeNode(value, original.right);
        node.left = original.left;
        return node;
    }
    
    
}

class Tree
{
    BinaryTreeNode last;
    
    public Tree(int r)
    {
        BinaryTreeNode n=new BinaryTreeNode(r, null);
        this.last=n;
    }
}
